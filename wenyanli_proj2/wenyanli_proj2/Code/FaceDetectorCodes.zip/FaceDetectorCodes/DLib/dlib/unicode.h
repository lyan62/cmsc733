// Copyright (C) 2007  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_UNICODe_TOP_
#define DLIB_UNICODe_TOP_ 

#include "unicode/unicode.h"

#endif // DLIB_UNICODe_TOP_

