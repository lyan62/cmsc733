#ifndef DLIB_REVISION_H
// Version:  19.2
// Date:     Mon Oct 10 19:34:36 EDT 2016
// Mercurial Revision ID:  0e6647d222c3
#define DLIB_MAJOR_VERSION  19
#define DLIB_MINOR_VERSION  2
#define DLIB_PATCH_VERSION  0
#endif
