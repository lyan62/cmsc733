// Copyright (C) 2013 Steve Taylor (steve98654@gmail.com)
// License: Boost Software License  See LICENSE.txt for the full license.
#ifndef DLIB_INTEGRATE_FUNCTION_ADAPT_SIMPSON_HEADER
#define DLIB_INTEGRATE_FUNCTION_ADAPT_SIMPSON_HEADER

#include "numerical_integration/integrate_function_adapt_simpson.h"

#endif // DLIB_INTEGRATE_FUNCTION_ADAPT_SIMPSON_HEADER
